#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/nthanhthan/Downloads/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/nthanhthan/Library/Mobile Documents/com~apple~CloudDocs/tuyen/garden_app"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/nthanhthan/Library/Mobile Documents/com~apple~CloudDocs/tuyen/garden_app/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_DEFINES=QVBQX05BTUU9W2Rldl1HYXJkZW4=,QVBQX1NVRkZJWD0uZGV2,QVBQX0lTX0RFQlVHPXk=,QVBQX0lTX0VOQUJMRV9TV0lUQ0hfRU5WPXk=,QVBQX0VOVklST05FTVRfVFlQRT1kZXZlbG9wbWVudA==,RkxVVFRFUl9XRUJfQVVUT19ERVRFQ1Q9dHJ1ZQ=="
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/nthanhthan/Library/Mobile Documents/com~apple~CloudDocs/tuyen/garden_app/.dart_tool/package_config.json"
