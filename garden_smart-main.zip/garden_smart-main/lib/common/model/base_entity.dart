mixin BaseEntity{
  Map<String, dynamic> toQuery();
}