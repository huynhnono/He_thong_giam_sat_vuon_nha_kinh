mixin DisposableMixin {
  Future<void> dispose();
}
