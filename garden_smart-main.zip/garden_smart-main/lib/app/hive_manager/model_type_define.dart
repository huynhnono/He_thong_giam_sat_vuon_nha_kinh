//Hive type id between 0 and 223
class ModelTypeDefine {
  static const int question = 1;
  static const String questionBox = "question-box";
  static const int chapter = 2;
  static const String chaptertbox = "chapter-box";
  static const int subject = 3;
  static const String subjectbox = "subject-box";
  static const int subjectKey = 4;
  static const String subjectKeybox = "subject-key-box";
  static const int subjectKeyModel = 5;
  static const String subjectKeyModelbox = "subject-Key-Model-box";
}
