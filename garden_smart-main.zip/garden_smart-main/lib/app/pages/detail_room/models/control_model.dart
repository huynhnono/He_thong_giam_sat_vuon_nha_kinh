class ControlModel {
  int index;
  bool value;
  String name;
  ControlModel({
    required this.index,
    required this.value,
    required this.name,
  });
}
