// ignore_for_file: lines_longer_than_80_chars
class AppApi {
  static const String apiVer = "";
  //static resources
  static const String chatGPTAnswer = "$apiVer/chat-gpt/conversation";
  static const String configPackage = "$apiVer/chat-gpt/products";
}
